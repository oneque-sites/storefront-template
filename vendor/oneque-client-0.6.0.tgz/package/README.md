# @oneque/client

원큐(Oneque) 헤드리스 CMS·커머스 백엔드의 공개 API를 감싼 타입 안전 클라이언트.

- 대상: 원큐를 데이터로 쓰는 **테넌트 사이트**(쇼핑몰·예약·콘텐츠).
- 성격: 얇은 `fetch` 래퍼 — **런타임 의존성 0**, ESM·CJS + 타입 선언 동봉.
- 동작: 응답 껍데기(`ApiResponse<T>`)를 벗겨 `data`만 반환, 실패는 `OnequeError`로 throw.
- 전제: **서버 사이드 전용**(RSC·route handler·server action). 브라우저 직접 호출 미지원 (아래 참고).

## AI로 만든다면 `llms.txt`부터

- 이 패키지는 AI가 스토어프론트를 짓는 것을 전제로 설계됨.
- `llms.txt` 한 파일에 API 표면·서버 호출 규칙·결제 흐름·게스트 장바구니·주문 조회 전부 수록.
- 설치 후 경로: `node_modules/@oneque/client/llms.txt`.
- 사용법: 이 파일을 AI 컨텍스트로 주고 "상품·장바구니·결제 페이지를 만들어줘".

## 설치

```bash
npm install @oneque/client
```

- 버전 못 박기: tarball을 `vendor/`에 넣어 써도 결과는 npm 설치와 동일.
- ❌ 디렉터리 심링크(`file:<dir>`) 금지 — Next 16 Turbopack이 프로젝트 밖을 못 읽어 깨짐.

## 초기화

```ts
// lib/oneque.ts — 서버 전용 싱글턴
import {createOnequeClient} from "@oneque/client";

export const oneque = createOnequeClient({
    baseUrl: process.env.ONEQUE_API_BASE!,        // 예: http://localhost:8100 — /api는 안 붙인다
    tenant: process.env.ONEQUE_TENANT!,           // 모든 요청에 X-Tenant로 실린다
    secretKey: process.env.ONEQUE_STOREFRONT_KEY, // (선택) 서버 시크릿 — 아래 "시크릿 키" 참고
});
```

### 옵션 (`OnequeClientOptions`)

| 옵션 | 타입 | 필수 | 설명 |
|---|---|---|---|
| `baseUrl` | `string` | ✅ | 백엔드 베이스 URL. `/api`는 붙이지 않는다(클라이언트가 붙임). |
| `tenant` | `string` | ✅ | 테넌트 코드. 전 요청 `X-Tenant` 헤더. |
| `secretKey` | `string` | — | 스토어프론트 서버 시크릿(`oqsk_…`). 있으면 전 요청 `X-Storefront-Key` 헤더. |
| `fetch` | `typeof fetch` | — | `fetch` 구현 주입. 기본 전역 `fetch`(Node 18+). 캐시 래퍼·테스트용. |
| `headers` | `Record<string,string>` | — | 전 요청에 추가할 헤더. |
| `timeoutMs` | `number` | — | 요청 타임아웃. 기본 10초. |

## 서버 사이드 전용 (중요)

- 공개 API는 `X-Tenant`를 그대로 믿는다(비인증) → 브라우저 직접 호출 시 `baseUrl` 노출 + CORS 개방 필요.
- 그래서 **RSC / route handler(BFF) / server action**에서만 호출한다.
- 사용자별 상태(장바구니·결제)는 route handler로 프록시 (브라우저 ↔ route handler ↔ 원큐), 토큰은 httpOnly 쿠키.
- ❌ 클라이언트 컴포넌트에서 `@oneque/client` import 금지 — `baseUrl`·`secretKey` 노출.

### IP 민감 호출은 방문자 IP를 넘긴다

- 대상: `submitInquiry`·`submitLead`·`recordPostView`.
- 이유: 백엔드 IP 레이트리밋·조회 dedup은 `X-Forwarded-For` 첫 홉을 본다. 안 넘기면 테넌트 서버 IP로 뭉쳐 방문자 전원이 429.

```ts
// route handler 안
const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
await oneque.submitInquiry(input, {clientIp: ip});
```

## 시크릿 키 (`secretKey` · memo78)

- 역할: `X-Tenant` 무인증 신뢰의 **보안 승격** — 키가 테넌트 신원을 증명(백엔드에선 키가 정본).
- 형식: `oqsk_…`. 파트너 콘솔에서 발급(원문 1회 노출·재조회 불가·분실 시 회전).
- 하위호환: 안 주면 종전대로 `tenant`(X-Tenant)만으로 동작. dual 이행기엔 둘 다 보내도 무방(일치해야 함).

### 🔒 비밀 취급 규칙

- ✅ **서버 `.env`에만** 둔다(예: `ONEQUE_STOREFRONT_KEY`).
- ❌ `NEXT_PUBLIC_*` 접두사 금지 — 클라이언트 번들에 박힌다.
- ❌ 클라이언트 컴포넌트 import 금지.
- 유출 시: 콘솔에서 revoke → 재발급 → 서버 env 교체 배포.

### 관련 에러

- `401 STOREFRONT_KEY_REQUIRED` — 백엔드 `required` 모드인데 키 없음/무효. `secretKey` 설정 필요.
- `403 TENANT_MISMATCH` — `secretKey`가 `tenant`와 다른 테넌트의 키. 두 값 정합 확인.
- 둘 다 `OnequeError.isStorefrontKeyError === true`이며 안내 메시지가 매핑돼 있다.

## 메서드

### 콘텐츠·공개(무인증)

| 메서드 | 엔드포인트 | 반환 |
|---|---|---|
| `getSiteConfig(options?)` | `GET /api/public/site-config` | `SiteConfig` |
| `listCategories()` | `GET /api/public/categories` | `Category[]` |
| `listPosts(params?)` | `GET /api/public/posts` | `Paginated<PostSummary>` |
| `getPost(slug)` | `GET /api/public/posts/{slug}` | `PostDetail` |
| `recordPostView(slug, ctx?)` | `POST /api/public/posts/{slug}/view` | `boolean` |
| `getPage(slug, options?)` | `GET /api/public/pages/{slug}` | `PageContent` |
| `listMenus(options?)` | `GET /api/public/menus` | `Menu[]` |
| `getMediaUrl(id)` | `GET /api/public/media/{id}/url` | `MediaUrl` |
| `submitInquiry(input, ctx?)` | `POST /api/public/inquiries` | `InquiryCreated` |
| `submitLead(input, ctx?)` | `POST /api/public/leads` | `LeadCreated` |

### 커머스 카탈로그·후기(공개)

| 메서드 | 엔드포인트 | 반환 |
|---|---|---|
| `getProduct(slug, options?)` | `GET /api/public/products/{slug}` | `ProductDetail` |
| `listProducts(params?, options?)` | `GET /api/public/products` | `Paginated<ProductSummary>` |
| `listProductCategories(options?)` | `GET /api/public/product-categories` | `ProductCategory[]` |
| `listProductReviews(productId, params?, options?)` | `GET /api/public/products/{id}/reviews` | `Paginated<Review>` |
| `getProductReviewSummary(productId, options?)` | `GET /api/public/products/{id}/reviews/summary` | `RatingSummary` |
| `createProductReview(productId, input, accessToken)` | `POST /api/shop/products/{id}/reviews` | `Review` |

- 후기 조회는 **숫자 `productId`**(slug 아님) — `getProduct(slug).id`로 획득.
- 후기 작성은 로그인 필수 + 구매검증(본인·배송완료 이상·상품 일치).

### 고객 인증(소셜·토큰)

| 메서드 | 엔드포인트 | 반환 |
|---|---|---|
| `socialLogin(input)` | `POST /api/shop/auth/social` | `AuthTokens` |
| `refreshSession(refreshToken)` | `POST /api/shop/auth/refresh` | `AuthTokens` |
| `logout(accessToken)` | `POST /api/shop/auth/logout` | `string` |
| `getMe(accessToken)` | `GET /api/shop/me` | `CustomerSummary` |
| `getConsents(accessToken)` | `GET /api/shop/consents` | `ConsentStatus[]` |
| `updateConsents(accessToken, consents)` | `POST /api/shop/consents` | `string` |

### 예약(SERVICE 상품)

| 메서드 | 엔드포인트 | 반환 |
|---|---|---|
| `availability(params, options?)` | `GET /api/public/booking/availability` | `AvailabilitySlot[]` |
| `createBooking(accessToken, input)` | `POST /api/shop/booking/bookings` | `Booking` |
| `myBookings(accessToken)` | `GET /api/shop/booking/bookings` | `Booking[]` |
| `cancelBooking(accessToken, bookingCode)` | `POST /api/shop/booking/bookings/{code}/cancel` | `string` |
| `rescheduleBooking(accessToken, bookingCode, newSlotId)` | `POST /api/shop/booking/bookings/{code}/reschedule` | `Booking` |

- 가용 판정은 `AvailabilitySlot.availableCount`로 (카탈로그 `inStock` 아님 — 슬롯마다 정원 별도).
- 예약은 **카트에 담기지 않는다**(SERVICE는 `addToCart` 400 거부). 유료 예약은 `Booking.orderNo`로 결제 흐름을 탄다.

### 장바구니

| 메서드 | 엔드포인트 | 반환 |
|---|---|---|
| `getCart(session)` | `GET /api/shop/cart` | `Cart` |
| `addToCart(variantId, quantity, session)` | `POST /api/shop/cart/items` | `Cart` |
| `updateCartItem(variantId, quantity, session)` | `PATCH /api/shop/cart/items/{variantId}` | `Cart` |
| `removeFromCart(variantId, session)` | `DELETE /api/shop/cart/items/{variantId}` | `Cart` |
| `clearCart(session)` | `DELETE /api/shop/cart` | `Cart` |

- `ShopSession` = 로그인 `{accessToken}` 또는 게스트 `{cartSessionKey}`.

### 결제·주문·배송

| 메서드 | 엔드포인트 | 반환 |
|---|---|---|
| `checkout(input, session, idempotencyKey?)` | `POST /api/shop/checkout` | `OrderDetail` |
| `startPayment(orderNo, access)` | `POST /api/shop/orders/{orderNo}/payment/session` | `PaymentSession` |
| `confirmPayment(orderNo, providerParams, access)` | `POST /api/shop/orders/{orderNo}/payment/confirm` | `void` |
| `getOrder(orderNo, access)` | `GET /api/shop/orders/{orderNo}` | `OrderDetail` |
| `listMyOrders(accessToken, params?)` | `GET /api/shop/orders` | `Paginated<OrderSummary>` |
| `cancelOrder(orderNo, access)` | `POST /api/shop/orders/{orderNo}/cancel` | `OrderDetail` |
| `completeOrder(orderNo, access)` | `POST /api/shop/orders/{orderNo}/complete` | `OrderDetail` |
| `getShipment(orderNo, access)` | `GET /api/shop/orders/{orderNo}/shipment` | `ShipmentInfo` |

- `OrderAccess` = 로그인 `{accessToken}` 또는 게스트 `{phone}`(주문번호 + 연락처로 소유확인).
- `checkout`은 스냅샷 동결 + 재고 차감(상태 PENDING_PAYMENT). `idempotencyKey`로 재시도 안전(같은 키·다른 입력 = 409).
- `confirmPayment`는 위젯형 벤더(토스 등) 승인 확정 — 금액을 넘겨도 서버는 저장 금액으로 PG에 직접 확인.

## ISR 캐시 태그 (`ReadOptions`)

- 읽기 메서드에 `{tags: [...]}`를 넘기면 그 fetch에 `next.tags`가 실려 백엔드가 `revalidateTag`로 온디맨드 무효화.
- 태그 컨벤션: `site-config`·`products`·`product:{slug}`.
- 안 넘기면 세그먼트 기본 캐시만 적용(하위호환).

## 예시

```ts
const posts = await oneque.listPosts({size: 10, sort: "publishedAt,desc"});
const post = await oneque.getPost("hello-world");
const menus = await oneque.listMenus();
const product = await oneque.getProduct("tee", {tags: ["product:tee"]});
await oneque.submitInquiry({name, email, subject, message}, {clientIp});
```

## 에러 처리 (`OnequeError`)

- 실패는 전부 `OnequeError` throw. **원인 분기는 `code`로** (같은 status에 여러 원인 — `message`는 사람용 한국어, 문자열 매칭 금지).

| 멤버 | 설명 |
|---|---|
| `status` | HTTP 상태. 네트워크 실패·비JSON이면 `0`. |
| `code` | 기계 판독 에러코드(백엔드 `ErrorCode`). 구버전은 HTTP 사유구로 폴백. |
| `validationErrors` | 400 시 필드별 메시지. |
| `body` | 파싱된 원본 에러 본문. |
| `isRateLimited` | `status === 429`. |
| `isStorefrontKeyError` | `STOREFRONT_KEY_REQUIRED` 또는 `TENANT_MISMATCH`(memo78). |

```ts
import {OnequeError} from "@oneque/client";

try {
    await oneque.submitInquiry(form);
} catch (error) {
    if (error instanceof OnequeError) {
        if (error.isRateLimited) return "잠시 후 다시 시도해 주세요.";  // 429
        if (error.isStorefrontKeyError) throw error;                    // secretKey 오배선 — 서버 설정 점검
        if (error.status === 400) return error.validationErrors;        // 필드별 메시지
        if (error.code === "OUT_OF_STOCK") return "품절된 상품이 있습니다.";
    }
    throw error;
}
```

---

원큐(Oneque) — 헤드리스 커머스 플랫폼. 무엇을 파는지는 당신이, 파는 데 필요한 뒷단은 원큐가.

# @oneque/client

원큐(Oneque) 백엔드에 붙는 공식 API 클라이언트입니다. 상품·글·메뉴 같은 콘텐츠부터 장바구니·결제·주문까지, 원큐의 공개 API를 타입 안전하게 감싼 얇은 래퍼입니다. 만드시는 비즈니스 사이트(쇼핑몰·예약 등)가 원큐를 데이터로 쓸 때 이걸 끼우면 됩니다.

무겁지 않습니다. 런타임 의존성이 하나도 없고(브라우저·Node 18+의 `fetch`만 씁니다), ESM·CJS 둘 다에 타입 선언까지 들어 있습니다. 응답 껍데기(`ApiResponse<T>`)는 알아서 벗겨 `data`만 돌려주고, 뭔가 잘못되면 `OnequeError`로 던집니다.

## AI에게 맡기신다면 `llms.txt`부터 주십시오

이 패키지는 애초에 AI가 사이트를 짓는 것을 염두에 두고 만들었습니다. 그래서 `llms.txt` 한 파일에 API 표면, 서버에서 부르는 규칙, 결제 흐름, 게스트 장바구니, 주문 조회까지 필요한 것을 모두 적어 뒀습니다. AI에게 이 파일을 컨텍스트로 주고 "이걸로 상품·장바구니·결제 페이지를 만들어줘"라고 하면 됩니다. 설치하고 나면 `node_modules/@oneque/client/llms.txt`에 있습니다.

## 설치

```bash
npm install @oneque/client
```

원큐 사이트 템플릿처럼 버전을 못 박아 두려고 tarball을 `vendor/`에 넣어 쓰는 곳도 있는데, 결과는 npm 설치와 똑같습니다. 다만 디렉터리 심링크(`file:<dir>`)만은 쓰지 마십시오 — Next 16 Turbopack이 프로젝트 밖을 읽지 못해 깨집니다.

## 쓰기

**서버에서 씁니다.** RSC, route handler, server action 안에서만 씁니다. 공개 API는 `X-Tenant` 헤더를 그대로 믿기 때문에(비인증), 브라우저에서 바로 부르면 `baseUrl`이 노출되고 CORS까지 열어야 합니다. 그럴 이유가 없습니다.

```ts
import {createOnequeClient} from "@oneque/client";

const cms = createOnequeClient({
    baseUrl: process.env.ONEQUE_API_BASE!, // 예: http://localhost:8100 — /api는 안 붙입니다
    tenant: "your-tenant",                 // 모든 요청에 X-Tenant로 실려 나갑니다
});

const posts = await cms.listPosts({size: 10, sort: "publishedAt,desc"});
const post = await cms.getPost("hello-world");
const menus = await cms.listMenus();
```

### 있는 메서드

| 메서드 | 엔드포인트 | 반환 |
|---|---|---|
| `getSiteConfig()` | `GET /api/public/site-config` | `SiteConfig` |
| `listCategories()` | `GET /api/public/categories` | `Category[]` |
| `listPosts(params?)` | `GET /api/public/posts` | `Paginated<PostSummary>` |
| `getPost(slug)` | `GET /api/public/posts/{slug}` | `PostDetail` |
| `recordPostView(slug)` | `POST /api/public/posts/{slug}/view` | `boolean` |
| `getPage(slug)` | `GET /api/public/pages/{slug}` | `PageContent` |
| `listMenus()` | `GET /api/public/menus` | `Menu[]` |
| `getMediaUrl(id)` | `GET /api/public/media/{id}/url` | `MediaUrl` |
| `submitInquiry(input)` | `POST /api/public/inquiries` | `InquiryCreated` |

커머스(장바구니·결제·주문·배송·소셜 로그인) 메서드는 종류가 많아 여기 다 적지 않았습니다. 전체 목록과 흐름은 `llms.txt`에 정리돼 있습니다.

### 뭔가 잘못됐을 때

실패하면 `OnequeError`가 날아옵니다. `status`로 갈라 쓰면 됩니다.

```ts
import {OnequeError} from "@oneque/client";

try {
    await cms.submitInquiry(form);
} catch (error) {
    if (error instanceof OnequeError) {
        if (error.isRateLimited) return "잠시 후 다시 시도해 주세요."; // 429
        if (error.status === 400) return error.validationErrors;      // 필드별 메시지
    }
    throw error;
}
```

---

원큐(Oneque) — 헤드리스 커머스 플랫폼. 무엇을 파는지는 당신이, 파는 데 필요한 뒷단은 원큐가.

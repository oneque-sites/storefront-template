# @oneque/client

Oneque(원큐) 헤드리스 **CMS + 커머스** 공개 API 클라이언트. 테넌트 스토어프론트가 백엔드의
`/api/public/**`·`/api/shop/**` 엔드포인트를 타입 안전하게 소비하기 위한 얇은 래퍼다.

- **런타임 의존성 0** — 전역 `fetch`(Node 18+·브라우저)만 쓴다.
- **ESM + CJS** 이중 빌드 + 타입 선언 동봉.
- 응답 envelope(`ApiResponse<T>`)를 벗겨 `data` 만 돌려주고, 실패는 `OnequeError` 로 던진다.
- **커머스(v0.2)**: 카탈로그·장바구니·결제·주문·배송·고객 소셜 인증(게스트/로그인 식별).

## 🤖 AI 로 스토어프론트 만들기 — [`llms.txt`](./llms.txt)

이 패키지는 **AI(바이브코딩)가 Next.js 쇼핑몰/예약 사이트를 짓게 하는 것**을 전제로 설계됐다.
[`llms.txt`](./llms.txt) 한 파일에 API 표면·서버사이드 호출 규약·결제 플로우·게스트 카트·주문
조회 레시피가 다 있다. AI 에게 `llms.txt` 를 컨텍스트로 주고 "이 클라이언트로 상품/장바구니/결제
페이지를 만들어줘" 라고 하면 된다.

## 왜 이 패키지인가

테넌트 사이트를 CMS 레포에 흡수하지 않고 **독립 레포로 유지**하기 위한 이음새다. 백엔드와의
계약(엔드포인트·타입)은 이 패키지 한 곳에 있고, 테넌트 사이트는 이걸 의존성으로 소비한다.
계약이 바뀌면 이 패키지 버전을 올리고 각 사이트가 따라 올린다.

## 설치 (파일럿 단계, 아직 미배포)

`private` 패키지라 npm 레지스트리에 없다. **패킹한 tarball** 로 소비한다:

```bash
# 1) 클라이언트를 빌드하고 tarball 로 만든다
cd onequeue/packages/client
npm install && npm run build
npm pack --pack-destination .        # → oneque-client-0.1.0.tgz
```

```jsonc
// 테넌트 레포(예: hdsteeldent/frontend-member)/package.json
{
  "dependencies": {
    "@oneque/client": "file:../../onequeue/packages/client/oneque-client-0.1.0.tgz"
  }
}
```

> **왜 디렉터리 심링크(`file:../../onequeue/packages/client`)가 아니라 tarball 인가**:
> `file:` 로 디렉터리를 걸면 npm 이 심링크를 만드는데, 그 대상이 테넌트 프로젝트 루트 **밖**이라
> **Next 16 의 Turbopack 이 모듈을 해석하지 못한다**(`Module not found`). webpack(Next 15)은
> 되지만 Turbopack 은 안 된다. tarball 은 node_modules 에 실파일로 풀려 두 번들러 모두에서 동작하고,
> 나중에 레지스트리 퍼블리시로 넘어갈 때의 소비 형태와도 같다.
>
> 클라이언트를 고치면 **다시 `npm pack` 하고 테넌트에서 `npm install`** 해야 반영된다(파일럿 한정 —
> 안정화되면 퍼블리시로 전환).

## 사용

**서버 사이드에서 쓴다** — RSC·route handler·server action. 공개 API 는 `X-Tenant` 헤더를
그대로 믿으므로(비인증), 브라우저에서 직접 부르면 `baseUrl` 이 노출되고 CORS 를 열어야 한다.

```ts
import {createOnequeClient} from "@oneque/client";

const cms = createOnequeClient({
    baseUrl: process.env.API_BASE_URL!, // 예: http://localhost:8100 (/api 는 안 붙인다)
    tenant: "credium", // 모든 요청에 X-Tenant: credium
});

const posts = await cms.listPosts({size: 10, sort: "publishedAt,desc"});
const post = await cms.getPost("hello-world");
const menus = await cms.listMenus();
```

### 메서드

| 메서드 | 엔드포인트 | 반환 |
|---|---|---|
| `getSiteConfig()` | `GET /api/public/site-config` | `SiteConfig` |
| `listCategories()` | `GET /api/public/categories` | `Category[]` |
| `listPosts(params?)` | `GET /api/public/posts` | `Paginated<PostSummary>` |
| `getPost(slug)` | `GET /api/public/posts/{slug}` | `PostDetail` |
| `recordPostView(slug)` | `POST /api/public/posts/{slug}/view` | `boolean` |
| `getPage(slug)` | `GET /api/public/pages/{slug}` | `PageContent` |
| `listMenus()` | `GET /api/public/menus` | `Menu[]` |
| `getMediaUrl(id)` | `GET /api/public/media/{id}/url` | `MediaUrl` |
| `submitInquiry(input)` | `POST /api/public/inquiries` | `InquiryCreated` |

### 에러 처리

실패하면 `OnequeError` 를 던진다. `status` 로 분기한다:

```ts
import {OnequeError} from "@oneque/client";

try {
    await cms.submitInquiry(form);
} catch (error) {
    if (error instanceof OnequeError) {
        if (error.isRateLimited) return "잠시 후 다시 시도해 주세요."; // 429
        if (error.status === 400) return error.validationErrors; // 필드별 메시지
    }
    throw error;
}
```

## credium 문의 폼 이관 (Phase 6)

credium 은 지금 `app/api/contact/route.ts` 에서 `nodemailer` + `reCAPTCHA` 로 메일을 직접 쏜다.
이걸 Oneque 문의 접수로 바꾸면 메일 발송·자동회신·보관·rate-limit 을 백엔드가 맡는다:

```ts
// credium/frontend-member/app/api/contact/route.ts (교체 후)
import {createOnequeClient, OnequeError} from "@oneque/client";

const cms = createOnequeClient({baseUrl: process.env.API_BASE_URL!, tenant: "credium"});

export async function POST(req: Request) {
    const form = await req.json();
    try {
        const {id} = await cms.submitInquiry(form);
        return Response.json({id}, {status: 201});
    } catch (error) {
        if (error instanceof OnequeError) {
            return Response.json({message: error.message}, {status: error.status || 502});
        }
        throw error;
    }
}
```

`nodemailer`·`lib/email.ts`·`lib/recaptcha.ts` 의존이 사라진다(rate-limit 도 백엔드가 IP 기준으로 건다).

## 개발

```bash
npm install
npm run build       # dist/ (esm + cjs + d.ts)
npm run typecheck
npm test            # vitest — mock fetch 로 envelope·헤더·에러 매핑 검증
```

## 내용을 바꾸면 **반드시 버전을 올려라**

스토어프론트가 이 패키지를 tarball 로 문다(`file:../client/oneque-client-X.Y.Z.tgz`).
npm 은 그 tarball 을 **버전 키로 캐시**해서, 같은 버전으로 다시 pack 하면 **옛 내용이 계속
설치된다** — `dist` 는 새것인데 `node_modules` 는 옛것이라 "고쳤는데 왜 안 되지" 가 된다.

```bash
npm version patch --no-git-tag-version   # 반드시 먼저
npm run build && npm pack
# 소비자 package.json 의 tarball 경로를 새 버전으로 바꾸고 npm install
```
